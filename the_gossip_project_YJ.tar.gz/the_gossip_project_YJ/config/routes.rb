Rails.application.routes.draw do
  get 'user/show'
  get 'team/index'
  get 'team/contact'
  root 'welcome#accueil_inconnu'
  get 'welcome/:first_name', to:'welcome#accueil'
  get 'user/:id', to:'user#show', as: 'user_show_id' 
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
