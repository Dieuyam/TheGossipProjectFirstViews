class City < ApplicationRecord
	has_many :users
end