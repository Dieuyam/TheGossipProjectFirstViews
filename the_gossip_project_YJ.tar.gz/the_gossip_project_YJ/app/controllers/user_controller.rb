class UserController < ApplicationController
  def show
    @id = params[:id]
    @user = User.find(@id)
    @city = @user.city
    puts "Notre params est ici : #{params}"
  end
end
