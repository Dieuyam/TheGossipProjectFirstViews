class TeamController < ApplicationController
  def index
  end

  def contact
  end
end
